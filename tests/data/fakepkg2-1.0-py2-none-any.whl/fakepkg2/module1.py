""" First module """

def func1():
    return 1
