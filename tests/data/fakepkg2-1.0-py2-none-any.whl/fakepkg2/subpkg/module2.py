""" Second module """

def func2():
    return 2


def func3():
    return 3
